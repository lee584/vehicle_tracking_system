package com.example.vehicletrackingsystem.Repository;

import com.example.vehicletrackingsystem.model.VehicleTracking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface VehicleTrackingRepository extends JpaRepository<VehicleTracking, Long> {

}
