package com.example.vehicletrackingsystem.Service.Impl;

import com.example.vehicletrackingsystem.Repository.VehicleTrackingRepository;
import com.example.vehicletrackingsystem.Service.GoogleMapsService;
import com.example.vehicletrackingsystem.model.VehicleTracking;
import lombok.RequiredArgsConstructor;
import lombok.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class GoogleMapsServiceImpl implements GoogleMapsService {
    @Autowired
    private final VehicleTrackingRepository vehicleTrackingRepository;
    private String apiKey = "safasJKHUIGjniJZI392320ygui:KL;,";
    @Override
    public String getLocation(String address, VehicleTracking vehicleTracking) {
        RestTemplate restTemplate = new RestTemplate();

        String url = "https://maps.googleapis.com/maps/api/geocode/json?address=" +
                address + "&key=" + apiKey;

        vehicleTrackingRepository.save(vehicleTracking);

        return restTemplate.getForObject(url, VehicleTracking.class).toString();
    }
}
