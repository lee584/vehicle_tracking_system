package com.example.vehicletrackingsystem.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "VehicleTracking")
public class VehicleTracking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private double latitude;
    private double longitude;
    @OneToOne
    @JoinColumn(name = "Vehicle_id")
    private Vehicle vehicle;
}
