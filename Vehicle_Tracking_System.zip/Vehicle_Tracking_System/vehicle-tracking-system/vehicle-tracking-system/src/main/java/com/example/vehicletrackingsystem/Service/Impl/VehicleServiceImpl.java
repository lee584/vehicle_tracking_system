package com.example.vehicletrackingsystem.Service.Impl;

import com.example.vehicletrackingsystem.Repository.VehicleRepository;
import com.example.vehicletrackingsystem.Service.VehicleService;
import com.example.vehicletrackingsystem.model.Vehicle;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class VehicleServiceImpl implements VehicleService {
    @Autowired
    private final VehicleRepository vehicleRepository;
    @Override
    public void addVehicle(Vehicle vehicle) {
        vehicleRepository.save(vehicle);

    }

    @Override
    public Vehicle updateVehicle(Long id, Vehicle updatedVehicle) {
        Vehicle existingVehicle = vehicleRepository.findById(id).orElse(null);

        existingVehicle.setNameOfVehicle(updatedVehicle.getNameOfVehicle());
        existingVehicle.setNumberPlate(updatedVehicle.getNumberPlate());
        existingVehicle.setModel(updatedVehicle.getModel());
        existingVehicle.setColor(updatedVehicle.getColor());

        return vehicleRepository.save(existingVehicle);
    }

    @Override
    public void deleteVehicle(Long id) {
         vehicleRepository.deleteById(id);
    }
    @Override
    public List<Vehicle> getAllVehicles() {
        return vehicleRepository.findAll();
    }
}
