package com.example.vehicletrackingsystem.Repository;

import com.example.vehicletrackingsystem.model.Vehicle;
import org.springframework.data.domain.Example;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface VehicleRepository extends JpaRepository<Vehicle,Long> {
    Optional<Vehicle> findByNumberPlate(String numberPlate);
}
