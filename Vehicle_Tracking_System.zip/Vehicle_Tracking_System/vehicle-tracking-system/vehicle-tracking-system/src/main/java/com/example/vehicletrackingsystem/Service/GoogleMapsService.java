package com.example.vehicletrackingsystem.Service;

import com.example.vehicletrackingsystem.model.VehicleTracking;

public interface GoogleMapsService {
    public String getLocation(String address, VehicleTracking vehicleTracking);
}
