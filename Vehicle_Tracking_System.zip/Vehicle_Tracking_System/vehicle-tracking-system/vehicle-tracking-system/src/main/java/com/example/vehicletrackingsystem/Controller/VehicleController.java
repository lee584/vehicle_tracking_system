package com.example.vehicletrackingsystem.Controller;
import com.example.vehicletrackingsystem.Service.Impl.VehicleServiceImpl;
import com.example.vehicletrackingsystem.Service.VehicleService;
import com.example.vehicletrackingsystem.model.Vehicle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/vehicles")
public class VehicleController {

    private final VehicleService vehicleService;

    @Autowired
    public VehicleController(VehicleService vehicleService) {
        this.vehicleService = vehicleService;
    }

    @PostMapping("/register")
    public String createUser(@RequestBody Vehicle vehicle) {
        vehicleService.addVehicle(vehicle);

        return "successfully added a " +vehicle.getNameOfVehicle().toString();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Vehicle> updateVehicle(@PathVariable(value = "id") Long id, @RequestBody Vehicle updatedVehicle) {
        Vehicle vehicle =vehicleService.updateVehicle(id, updatedVehicle);
        return ResponseEntity.ok().body(vehicle);
    }

    @DeleteMapping("/{id}")
    public void deleteVehicle(@PathVariable Long id) {
        vehicleService.deleteVehicle(id);
    }
    @GetMapping
    public ResponseEntity<List<Vehicle>> getAllProducts() {
        List<Vehicle> products = vehicleService.getAllVehicles();
        return ResponseEntity.ok().body(products);
    }
}

