package com.example.vehicletrackingsystem.Service;

import com.example.vehicletrackingsystem.model.Vehicle;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface VehicleService {

    public void addVehicle(Vehicle vehicle);
    public Vehicle updateVehicle(Long id, Vehicle updatedVehicle);
    public void deleteVehicle(Long id);
    public List<Vehicle> getAllVehicles();

}
